const API_BASE = "http://localhost:5000";

const screens = {
  login: document.getElementById("screen-login"),
  userDetails: document.getElementById("screen-user-details"),
  userDashboard: document.getElementById("screen-user-dashboard"),
  adminDashboard: document.getElementById("screen-admin-dashboard"),
};

const loginForm = document.getElementById("login-form");
const detailsForm = document.getElementById("details-form");

const loginMessage = document.getElementById("login-message");
const detailsMessage = document.getElementById("details-message");
const adminMessage = document.getElementById("admin-message");

const detailsUsername = document.getElementById("details-username");
const adminUsersBody = document.getElementById("admin-users-body");

const dashUsername = document.getElementById("dash-username");
const dashName = document.getElementById("dash-name");
const dashLocation = document.getElementById("dash-location");
const dashLoginTime = document.getElementById("dash-login-time");

document.getElementById("logout-user").addEventListener("click", logout);
document.getElementById("logout-admin").addEventListener("click", logout);

loginForm.addEventListener("submit", onLogin);
detailsForm.addEventListener("submit", onSaveDetails);

init();

function init() {
  const session = getSession();

  if (!session) {
    showScreen("login");
    return;
  }

  if (session.role === "admin") {
    loadAdminDashboard();
    return;
  }

  if (session.user && session.user.name && session.user.location) {
    renderUserDashboard(session.user);
  } else {
    detailsUsername.textContent = session.username || "";
    showScreen("userDetails");
  }
}

function showScreen(screenName) {
  Object.values(screens).forEach((el) => el.classList.add("hidden"));
  screens[screenName].classList.remove("hidden");
}

function getSession() {
  const raw = localStorage.getItem("exp4_session");
  return raw ? JSON.parse(raw) : null;
}

function setSession(data) {
  localStorage.setItem("exp4_session", JSON.stringify(data));
}

function clearMessages() {
  loginMessage.textContent = "";
  detailsMessage.textContent = "";
  adminMessage.textContent = "";
}

async function onLogin(e) {
  e.preventDefault();
  clearMessages();

  const formData = new FormData(loginForm);
  const payload = {
    username: formData.get("username").trim(),
    password: formData.get("password").trim(),
    role: formData.get("role"),
  };

  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();

    if (!res.ok || !data.success) {
      loginMessage.textContent = data.message || "Login failed.";
      return;
    }

    if (data.role === "admin") {
      setSession({ role: "admin" });
      await loadAdminDashboard();
      return;
    }

    setSession({ role: "user", username: data.username, user: null });
    detailsUsername.textContent = data.username;
    detailsForm.reset();
    showScreen("userDetails");
  } catch (err) {
    loginMessage.textContent = "Cannot connect to backend. Start server first.";
  }
}

async function onSaveDetails(e) {
  e.preventDefault();
  clearMessages();

  const session = getSession();
  if (!session || !session.username) {
    showScreen("login");
    return;
  }

  const formData = new FormData(detailsForm);
  const payload = {
    username: session.username,
    name: formData.get("name").trim(),
    location: formData.get("location").trim(),
  };

  try {
    const res = await fetch(`${API_BASE}/user-details`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();

    if (!res.ok || !data.success) {
      detailsMessage.textContent = data.message || "Failed to save details.";
      return;
    }

    const updatedSession = {
      role: "user",
      username: session.username,
      user: data.user,
    };
    setSession(updatedSession);
    renderUserDashboard(data.user);
  } catch (err) {
    detailsMessage.textContent = "Cannot connect to backend. Start server first.";
  }
}

function renderUserDashboard(user) {
  dashUsername.textContent = user.username || "-";
  dashName.textContent = user.name || "-";
  dashLocation.textContent = user.location || "-";
  dashLoginTime.textContent = user.loginTime
    ? new Date(user.loginTime).toLocaleString()
    : "-";

  showScreen("userDashboard");
}

async function loadAdminDashboard() {
  clearMessages();
  showScreen("adminDashboard");
  adminUsersBody.innerHTML = "";

  try {
    const res = await fetch(`${API_BASE}/admin/users`);
    const users = await res.json();

    if (!res.ok || !Array.isArray(users)) {
      adminMessage.textContent = "Failed to load users.";
      return;
    }

    if (users.length === 0) {
      adminMessage.textContent = "No users found.";
      return;
    }

    users.forEach((user, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${index + 1}</td>
        <td>${safe(user.username)}</td>
        <td>${safe(user.name)}</td>
        <td>${safe(user.location)}</td>
        <td>${user.loginTime ? new Date(user.loginTime).toLocaleString() : "-"}</td>
      `;
      adminUsersBody.appendChild(tr);
    });
  } catch (err) {
    adminMessage.textContent = "Cannot connect to backend. Start server first.";
  }
}

function safe(value) {
  return String(value ?? "-")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function logout() {
  localStorage.removeItem("exp4_session");
  loginForm.reset();
  detailsForm.reset();
  clearMessages();
  showScreen("login");
}
